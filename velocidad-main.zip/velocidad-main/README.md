# velocidad

pagina en html y php para medir velocidad
https://www.sysadminsdecuba.com/2018/04/sysadmin-medir-la-velocidad-de-nuestra-red/
